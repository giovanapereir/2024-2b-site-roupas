# 2024-2b-site-publicidade-sacole
Exercício em HTML e CSS
